package com.example.jobssearch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class provider_registration : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_provider_registration)
    }
}