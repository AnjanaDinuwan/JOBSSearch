package com.example.jobssearch

class JobModel {
    var job_name : String = ""
    var job_description : String = ""
}